﻿using System;

namespace $ext_rootnamespace$.$safeprojectname$.Models.Instrutor
{
    public class InstrutorModel
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
    }
}
